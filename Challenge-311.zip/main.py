Def linearsearchproduct(product list, target product):
Indices=[] 
For index, product in enumerate(product list):
If product==target product:
Indices.append(index)


Return Indices

#example usage:
Products=["shoes", "boat", "loafer", "shoes","sandal","shoes"] 
Target="shoes" 
Result=linearsearchproduct(products, target) 
Print(result)