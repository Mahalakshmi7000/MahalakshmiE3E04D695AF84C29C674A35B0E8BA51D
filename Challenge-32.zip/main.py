Class student:
Def_inti_(self, name, roll_number, cgpa) :
Self.name=name
Self.roll_number=roll_number
Self.cgpa=cgpa

Def sort_student(student_list) :
#sort the list of students in descending order of CGPA
Sorted_students=sorted(student_list,
Key=lambda student:student. Cgpa,
Reverse=true)
#syntax_lambda arg:exp
Return sorted=students


#example usage:
Students=[
 Students("stephen", "A123", 7.8),
Student("karthik", "A124", 8.9),
Student("santhos", "A125", 9.1),
Student("komban","A126",9.9),
]
Sorted_students=sort_student(students)
#print the sorted list of students
For students in sorted_students:

Print("Name:{ }, Roll number:{ }. CGPA{ }".
format(students. name, students. Roll_number, students. Cpga))